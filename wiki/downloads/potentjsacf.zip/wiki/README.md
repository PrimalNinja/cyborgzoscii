# CyborgWiki v20250708

CyborgWiki is an extremely small wiki renderer which will convert a wiki syntax into html. It is created as a JavaScript library suitable for integration into any web application. It has it's limitations due to it's size, it is not a real wiki parser, but does an extremely commendable job using some regex magic.

Supports:

- Placeholder Substitution
- 4 Heading Sizes
- Bold Text
- Code Fragments
- Horizontal Rule
- Internal & External Links (Pages or File Downloads)
- Internal & External Images
- Ordered & Unordered Lists
- Simple Tables

- Julian

