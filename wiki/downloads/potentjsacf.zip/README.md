# PotentJS Adventure Creation Framework v20250708

PotentJS Adventure Creation Framework is a powerful JavaScript-based text adventure framework for creating sophisticated interactive fiction using an accessible, script-like syntax.

- Julian

